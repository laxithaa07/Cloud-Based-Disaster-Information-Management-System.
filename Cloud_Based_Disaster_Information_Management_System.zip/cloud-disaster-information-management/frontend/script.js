const $ = (selector) => document.querySelector(selector);
const formPanel = $("#form-panel");
const incidentForm = $("#incident-form");
const incidentList = $("#incident-list");
const emptyState = $("#empty-state");
const messageBox = $("#message");
let incidents = [];

$("#new-report-button").addEventListener("click", () => {
  formPanel.hidden = false;
  formPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  $("#type").focus();
});
function closeForm() { formPanel.hidden = true; incidentForm.reset(); $("#form-error").textContent = ""; }
$("#close-form").addEventListener("click", closeForm);
$("#cancel-form").addEventListener("click", closeForm);
$("#search").addEventListener("input", renderIncidents);
$("#status-filter").addEventListener("change", renderIncidents);

function showMessage(text, isError = false) {
  messageBox.textContent = text;
  messageBox.classList.toggle("error", isError);
  messageBox.hidden = false;
  window.clearTimeout(showMessage.timer);
  showMessage.timer = window.setTimeout(() => { messageBox.hidden = true; }, 4500);
}
async function api(path = "/api/incidents", options = {}) {
  const response = await fetch(path, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
async function loadIncidents() {
  try {
    incidents = await api();
    updateStats();
    renderIncidents();
  } catch (error) {
    showMessage("Could not connect to the Java backend. Start the server using the README instructions.", true);
    $("#result-count").textContent = "Backend unavailable";
    emptyState.hidden = false;
  }
}
incidentForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  $("#form-error").textContent = "";
  const button = $("#submit-report");
  button.disabled = true;
  const payload = {
    type: $("#type").value,
    severity: $("#severity").value,
    location: $("#location").value.trim(),
    description: $("#description").value.trim(),
    contact: $("#contact").value.trim()
  };
  try {
    await api("/api/incidents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    closeForm();
    await loadIncidents();
    showMessage("Disaster report saved successfully.");
  } catch (error) {
    $("#form-error").textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

async function changeStatus(id, status) {
  try {
    await api(`/api/incidents?id=${encodeURIComponent(id)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    await loadIncidents();
    showMessage("Incident status updated.");
  } catch (error) {
    showMessage(error.message, true);
  }
}
async function deleteIncident(id) {
  if (!window.confirm("Delete this incident report? This cannot be undone.")) return;
  try {
    await api(`/api/incidents?id=${encodeURIComponent(id)}`, { method: "DELETE" });
    await loadIncidents();
    showMessage("Incident report deleted.");
  } catch (error) {
    showMessage(error.message, true);
  }
}
function updateStats() {
  $("#total-count").textContent = String(incidents.length);
  $("#critical-count").textContent = String(incidents.filter(x => x.severity === "Critical").length);
  $("#active-count").textContent = String(incidents.filter(x => x.status !== "Resolved").length);
}
function renderIncidents() {
  const term = $("#search").value.trim().toLowerCase();
  const status = $("#status-filter").value;
  const filtered = incidents.filter(item => {
    const searchable = [item.id, item.type, item.severity, item.location, item.description, item.contact, item.status].join(" ").toLowerCase();
    return searchable.includes(term) && (!status || item.status === status);
  });
  $("#result-count").textContent = `${filtered.length} report${filtered.length === 1 ? "" : "s"}`;
  incidentList.replaceChildren();
  emptyState.hidden = filtered.length > 0;
  for (const item of filtered) incidentList.append(createIncidentCard(item));
}
function createIncidentCard(item) {
  const card = document.createElement("article");
  card.className = "incident";
  const main = document.createElement("div");
  main.className = "incident-main";
  const top = document.createElement("div");
  top.className = "incident-top";
  const title = document.createElement("h3"); title.textContent = item.type;
  const id = document.createElement("span"); id.className = "id"; id.textContent = item.id;
  const severity = document.createElement("span"); severity.className = `tag severity-${item.severity.toLowerCase()}`; severity.textContent = item.severity;
  const statusTag = document.createElement("span"); statusTag.className = "tag status"; statusTag.textContent = item.status;
  top.append(title, id, severity, statusTag);
  const location = document.createElement("p"); location.className = "incident-location"; location.textContent = `⌖ ${item.location}`;
  const description = document.createElement("p"); description.className = "incident-description"; description.textContent = item.description;
  const meta = document.createElement("p"); meta.className = "incident-meta";
  const date = new Date(item.createdAt);
  meta.textContent = `${item.contact ? `Reported by ${item.contact} · ` : ""}${Number.isNaN(date.getTime()) ? "" : date.toLocaleString()}`;
  main.append(top, location, description, meta);
  const actions = document.createElement("div"); actions.className = "incident-actions";
  const select = document.createElement("select"); select.setAttribute("aria-label", `Update status for ${item.id}`);
  for (const value of ["Reported", "Verifying", "Response in progress", "Resolved"]) {
    const option = document.createElement("option"); option.value = value; option.textContent = value;
    option.selected = value === item.status; select.append(option);
  }
  select.addEventListener("change", () => changeStatus(item.id, select.value));
  const remove = document.createElement("button"); remove.className = "delete-button"; remove.type = "button"; remove.textContent = "Delete report";
  remove.addEventListener("click", () => deleteIncident(item.id));
  actions.append(select, remove);
  card.append(main, actions);
  return card;
}
loadIncidents();
